Trixie - Tricks for IE


Several years ago, there was Trix on http://www.bhelpuri.net/Trixie/ .
Original description:
 Trixie is to Internet Explorer as Greasemonkey is to Firefox.
 It lets you remix the Web via scripts.
 You may do this to either make it more readable,
 fix bugs or to even add little features to make the site more usable to you.
 Trixie by itself does none of this.
 It is just a plugin for Internet Explorer that enables executing chunks of JavaScript code and
 thus lets you use the Web the way you want to use it. 
But there is no official sites, only a copy of Ver.0.2.3 could be gotton.

I got a trouble after I installed IE11.
Links of Search Result Page of Google are not direct links but redirector.
When I ckicked a link of those, jumped to redirector(http://www.google.co.jp/url?sa=t&rct=j...) then
jumped to desired page. It caused me clicking backword button twice if I'd like to go back to SERP.
My IE11 will always crash when I click backword button twice.
I Googled and found some Greasemonkies(Linkify Google Search Results,etc.)
but those were not able to solve my problem.
I've tried to solve my problem making own Greasemonkey and got it.
I've looking for the way how my Greasemonkey could be applied on IE11.
Then I got Trixie binary and started to rewrite it.


Features:
* almost same as original Trixie
* single exe file
* self COM register
* WPF options dialog
* cross-domain XmlHttpRequest(GM_xmlhttpRequest) is eliminated
* Google DeLinker Greasemonkey script
* .NET 4.5 required


Usgae:
1. install and COM register
 This app will write Trixie.config.xml on the installed folder so make sure the folder to be installed
 you have permission to write.
 This app requirs UAC elevation (on registing).
 Launch Trixie.exe , confirmation dialog will appear.

2. Scripts enable/disable
 IE menu <Tools>-<Trixie Option...> will open the dialog.

3. Add/Remove scripts
 Scripts are loaded from <installed folder>\Scripts.
 You can put some *.js files which are Greasemonkey formatted.

4. uninstall
 Close all IE windows then launch Trixie.exe.
 Confirmatin dialog will appear.


Developing and Testimg
 Machine            MacBook Pro 13(Early 2011) MC724J/A 2.7GHz(Core i7) 4GB-MEM 500GB-HDD 
 OS                 Windows 7 Ultimate SP1 (32bit) 
                    .NET Framework 4.5.1
 IE                 11.0.9600.16476
 Development Tool   Visual Studio 2013 
                    own made Version management add-in 


Copyright (C) 2013 Mizutama(水玉 ◆qHK1vdR8FRIm)
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


